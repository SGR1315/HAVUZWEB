document.getElementById('homeButton').addEventListener('click', function() {
    window.location.href = 'index.html'; // Ana sayfanızın dosya adı veya URL'si
});
